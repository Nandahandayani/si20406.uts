package com.ryz.aplikasitodo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listview;
    Button btnTambah;
    EditText edtTambah;
    ArrayList<String> arraynames = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = findViewById(R.id.lstView);
        btnTambah = findViewById(R.id.btnTambah);
        edtTambah = findViewById(R.id.edtTambah);

        final ArrayAdapter <String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, arraynames);
        listview.setAdapter(adapter);

        btnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtTambah.length() == 0) {
                    Toast.makeText(MainActivity.this, "Masukan Data", Toast.LENGTH_SHORT).show();
                } else {
                    arraynames.add(0, edtTambah.getText().toString().trim());
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }
}